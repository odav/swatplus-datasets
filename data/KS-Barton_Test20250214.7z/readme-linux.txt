To run, copy the files to the directory containing your model input files (often called TxtInOut)
Make sure the files can be executed.

If needed, run:
chmod 755 rev60.5.7_64rel_linux
chmod 755 rev60.5.7_64debug_linux